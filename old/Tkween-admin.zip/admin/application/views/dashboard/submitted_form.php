<section class="content">
  
      <div class="row">
       <div class="col-xs-12">
       </div>
        <div class="col-xs-12">
         <div class="box box-widget">
            <div class="box-header with-border" style="text-align:center">
             
         <center>
              <h3 class="box-title" style="font-weight:500; font-size:22px;">جميع البيانات المقدمة <i style=" font-size:20px" class="fa fa-star-o"></i>
</h3>
<p style="margin-bottom:0">فيما يلي قائمة بجميع البيانات المقدمة
</p>
              </center>
             </div>
             

            <div class="box-body  " style="margin-top:20px;">
              <div class="table-responsive ">
              <table class="table table-bordered table-hover">
              <thead>
                <tr>
                
               <th>عمل</th>
               <th>تحميل PDF</th>
               <th>زمن</th>
               <th>تاريخ</th>
              	 <th>نسبة المؤلف</th> 
               <th>سعر الباقة</th>
               <th>الألوان</th>
               <th>نوع الكتاب</th>
               <th>إسم الكتاب</th>
               <th>الإسم</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($rec as $ss): ?>
                <tr>
                <td >
                    
                    <a onclick="return confirm('Want to Delete?')" href="<?=$this->load->config->base_url() ?>dashboard/delete_submitted_form/<?= $ss['id'] ?>"  class="btn btn-danger btn-xs" title="Delete " ><i class="fa fa-times" ></i> </a>
                    </td>
                <td><a href="<?= $this->load->config->base_url() ?>dashboard/contract/<?= $ss['id'] ?>" target="_blank">تحميل</a></td>
                 <td><?= $ss['tm'] ?></td>
                    <td><?= $ss['dt'] ?></td>
                    <td><?= $ss['ration'] ?></td>
                    <td><?= $ss['price'] ?></td>
                  <td><?= $ss['color'] ?></td>
                <td><?= $ss['book_type'] ?></td>
                <td><?= $ss['book_name'] ?></td>
                	<td><?= $ss['name'] ?></td>
                   
               
                    
                   
                    
                   
                </tr>
                <?php endforeach ?>
                </tbody> 
                
                
              </table>
               <?php echo $this->pagination->create_links() ?>
            </div></div>
            
          </div>
        </div>
      </div>
    </section>