</div>

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.0.0
    </div>
    <strong>حقوق النشر ©  <?= date('Y') ?> Tkweenonline. كل الحقوق محفوظة.</strong> 
  </footer>


<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/fastclick/lib/fastclick.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/dist/js/adminlte.min.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/bower_components/chart.js/Chart.js"></script>
<script src="<?=$this->load->config->base_url() ?>cms-admin/dist/js/pages/dashboard2.js"></script>

</body>

</html>
