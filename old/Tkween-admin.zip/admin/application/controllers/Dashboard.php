<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller 
{
	
	public function __construct()
	{
		parent::__construct();
		
		
		$con = $this->db->get('cms-config')->result_array();	
		$this->config->set_item('site_name', $con[0]['site_name']); 
		$this->config->set_item('logo', $con[0]['url'].$con[0]['logo']);   
		$this->config->set_item('fev', $con[0]['url'].$con[0]['fev']);
		 
		
		if(!$this->session->userdata('id'))
		{
			redirect(base_url().'');
		}
		
		
	}
	private function __pagination_data($url,$table_name,$data, $limit,$seg)
	{
		$config=array(
						'base_url'			=> base_url($url),
						'per_page' 			=> $limit,
						'total_rows'		=> $this->db->where($data)->get($table_name)->num_rows(),
						'full_tag_open' 	=> "<ul class='pagination'>",
						'full_tag_close'	=> "</ul>",
						'first_tag_open'	=> "<li>",
						'first_tag_close'   => "</li>",
						'last_tag_open'		=> "<li>",
						'last_tag_close'    => "</li>",
						'next_tag_open'		=> "<li>",
						'next_tag_close'    => "</li>",
						'prev_tag_open'		=> "<li>",
						'prev_tag_close'    => "</li>",
						'num_tag_open'		=> "<li>",
						'num_tag_close'     => "</li>",
						'cur_tag_open'      => "<li ><a class='active'>",
						'cur_tag_close'		=> "</a></li>"
		             );
					  $this->pagination->initialize($config);
					 return $this->admin_work->peg($table_name,$data,$config['per_page'] , $this->uri->segment($seg));
	}
	public $data=array();

	public function logout()
	{
		
		
		$this->session->unset_userdata('id');
		$this->session->unset_userdata('level');
		redirect(base_url().'');
	}
	private function page($page,$data=false)
	{
		$this->load->view('dashboard/header');
		$this->load->view('dashboard/'.$page , $data);
		$this->load->view('dashboard/footer');
	}
	public function index()
	{
		$this->page('home',$this->data);
	}
	public function submitted_form()
	{	
		$this->data['rec'] =  $this->__pagination_data('dashboard/submitted_form','submitted_form',$this->data, 50,3);
		$this->page('submitted_form',$this->data);
	}
	
	public function delete_submitted_form()
	{
		$this->db->where('id',$this->uri->segment(3))->delete('submitted_form');
		redirect(base_url().'dashboard/submitted_form');
	}
	public function contract()
	{
		$this->load->view('dashboard/contract',$this->data);
	}
	public function users()
	{
		$this->page('users',$this->data);
	}
	public function add_user_data()
	{
		
		$this->data['name']= trim($this->input->post('name'));
		$this->data['email']= trim($this->input->post('email'));
		$this->data['pass']= trim($this->input->post('pass'));
		$this->data['status']=1;
		$this->data['dt']=date('d F Y');
		
		 if( $_FILES['pic']['name'])
       {
      	
			$folder  = 'upload/';
			$nn = $_FILES['pic']['name'];
			 $extension = pathinfo($_FILES["pic"]["name"], PATHINFO_EXTENSION);
			
			
			
			$a = explode($extension,$nn);
			
			$t1 = str_replace(' ','',$a[0]);
			$t1 = str_replace('.','',$t1);
			$file_name = strtolower($t1.rand(0,1000000).md5($nn).'.'.$extension);
			
			
			
			$this->data['pic'] = $folder.$file_name ;
			$pic = $folder.$file_name ;
			move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$file_name); 
       }
	   else
	   {
		$this->data['pic'] =   'cms-admin/image.jpg';
	   }
		
		 $this->db->insert('cms-users',$this->data);
		   redirect(base_url().'dashboard/users');
	}
	public function update_user_data()
	{
		
		$this->data['name']= trim($this->input->post('name'));
		$this->data['email']= trim($this->input->post('email'));
		$this->data['pass']= trim($this->input->post('pass'));
		
		if( $_FILES['pic']['name'])
       {
      	
			$folder  = 'upload/';
			$nn = $_FILES['pic']['name'];
			 $extension = pathinfo($_FILES["pic"]["name"], PATHINFO_EXTENSION);
			
			
			
			$a = explode($extension,$nn);
			
			$t1 = str_replace(' ','',$a[0]);
			$t1 = str_replace('.','',$t1);
			$file_name = strtolower($t1.rand(0,1000000).md5($nn).'.'.$extension);
			
			
			
			$this->data['pic'] = $folder.$file_name ;
			$pic = $folder.$file_name ;
			move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$file_name); 
       }
	   else
	   {
		$this->data['pic'] =  $this->input->post('path');
	   }
		
		 $this->db->where('id',$this->input->post('id'))->update('cms-users',$this->data);
		  redirect(base_url().'dashboard/users');
	}
	public function delete_user()
	{
		$this->db->where('id',$this->uri->segment(3))->delete('cms-users');
		 redirect(base_url().'dashboard/users');
	}
	
	
	
}



















