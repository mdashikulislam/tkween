<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Site extends CI_Controller 
{
	public $data = array();

	public function login_process()
	{
		$this->data['email'] = $this->input->post('email');
		$this->data['pass'] = $this->input->post('pass');
		$rec = $this->db->where($this->data)->get('cms-users')->result_array();
		if(count($rec))
		{
			$this->session->set_userdata(array('id'=>$rec[0]['id']));
			
				
					redirect(base_url('dashboard'));
				
			}
			else
			{
				redirect(base_url());
			}
	}
	

	public function index()
	{
		if($this->session->userdata('id'))
		{
			redirect(base_url('dashboard'));
		}
	  $this->load->view('dashboard/login');
	}
	
	public function add_data()
	{
		$this->data['name']= $this->input->post('name');
		$this->data['email']= $this->input->post('email');
		$this->data['phone']= $this->input->post('phone');
		$this->data['pasport']= $this->input->post('id_or_pass');
		$this->data['country']= $this->input->post('contry');
		$this->data['nationality']= $this->input->post('nationality');
		$this->data['title']= $this->input->post('nationality');
		$this->data['city']= $this->input->post('city');
		$this->data['bank_name']= $this->input->post('bank_name');
		$this->data['bank_account_ipan']= $this->input->post('bank_account_ipan');
		$this->data['book_name']= $this->input->post('book_name');
		$this->data['book_type']= $this->input->post('book_type1');
		$this->data['color']= $this->input->post('book_type2');
		$this->data['price']= $this->input->post('price');
		$this->data['ration']= $this->input->post('percentage');
		$this->data['dt']=date('F d, Y');
		$this->data['tm']=date('H:i A');
		$this->db->insert('submitted_form',$this->data);
		
		redirect('http://tkweenonline.com/thanks.html');
        //echo '<script>window.location="thanks.html"</script>';
	}
	
	

    
}
